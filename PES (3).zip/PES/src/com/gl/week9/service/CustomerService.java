package com.gl.week9.service;

import com.gl.week9.Exceptions.IdNotFoundException;
import com.gl.week9.Exceptions.NoDataException;
import com.gl.week9.dao.CustomerDao;
import com.gl.week9.model.Customer;

import java.sql.SQLException;
import java.util.List;

public class CustomerService {
    CustomerDao customerDao;

    public CustomerService() {
        this.customerDao = new CustomerDao();
    }

    public List<Customer> getCustomers() throws ClassNotFoundException {
        List<Customer> customers;
        try {
            customers = customerDao.getCustomers();
        } catch (SQLException e){
            throw new NoDataException("There is not even a single record");
        }
        return customers;
    }
    public Customer getCustomerById(Integer id){
        try {
            return customerDao.getCustomerById(id);
        } catch (SQLException | ClassNotFoundException e) {
            throw new IdNotFoundException("data with the given id is not available");
        }
    }
}
