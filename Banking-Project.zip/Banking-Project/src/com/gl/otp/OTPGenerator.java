package com.gl.otp;

public class OTPGenerator {
    public int generateOTP(){
        int random = (int) (Math.random() * 9000 + 1000);
        return random;
    }
}
