package com.gl.week8.designpatterns;

public class FactoryDemo {
    public static void main(String[] args) {
        IphoneType eleven = IphoneType.IPHONE11;
        IphoneType thirteen = IphoneType.IPHONE13;

        IphoneType fifteen = IphoneType.IPHONE15;

        Iphone iphone11 = IphoneFactory.CreateIphone(eleven);
        Iphone iphone13 = IphoneFactory.CreateIphone(thirteen);

        Iphone iphone15 = IphoneFactory.CreateIphone(fifteen);

        System.out.println(iphone11);
        System.out.println(iphone15);
        System.out.println(iphone13);

    }
}

interface Iphone{
    int getRam();
    int getScreenSize();
    int getMemory();
}

class Iphone11 implements Iphone{

    private int ram;
    private int screenSize;
    private int memory;

    public Iphone11(int ram, int screenSize, int memory) {
        this.ram = ram;
        this.screenSize = screenSize;
        this.memory = memory;
    }

    @Override
    public String toString() {
        return "Iphone11{" +
                "ram=" + ram +
                ", screenSize=" + screenSize +
                ", memory=" + memory +
                '}';
    }

    @Override
    public int getRam() {
        return ram;
    }

    @Override
    public int getScreenSize() {
        return screenSize;
    }

    @Override
    public int getMemory() {
        return memory;
    }
}

class Iphone13 implements Iphone{

    private int ram;
    private int screenSize;
    private int memory;

    public Iphone13(int ram, int screenSize, int memory) {
        this.ram = ram;
        this.screenSize = screenSize;
        this.memory = memory;
    }

    @Override
    public String toString() {
        return "Iphone13{" +
                "ram=" + ram +
                ", screenSize=" + screenSize +
                ", memory=" + memory +
                '}';
    }

    @Override
    public int getRam() {
        return ram;
    }

    @Override
    public int getScreenSize() {
        return screenSize;
    }

    @Override
    public int getMemory() {
        return memory;
    }
}
class Iphone15 implements Iphone{

    private int ram;
    private int screenSize;
    private int memory;

    public Iphone15(int ram, int screenSize, int memory) {
        this.ram = ram;
        this.screenSize = screenSize;
        this.memory = memory;
    }
    @Override
    public int getRam() {
        return ram;
    }

    @Override
    public String toString() {
        return "Iphone15{" +
                "ram=" + ram +
                ", screenSize=" + screenSize +
                ", memory=" + memory +
                '}';
    }

    @Override
    public int getScreenSize() {
        return screenSize;
    }

    @Override
    public int getMemory() {
        return memory;
    }
}


class IphoneFactory{
    public static Iphone CreateIphone(IphoneType type){
        if (type.equals(IphoneType.IPHONE11)){
            return new Iphone11(4, 5, 16);
        }
        else if (type.equals(IphoneType.IPHONE13)){
            return new Iphone11(4, 6, 128);
        }
        else if (type.equals(IphoneType.IPHONE15)){
            return new Iphone11(16, 8, 256);
        }
        return null;
    }
}

enum IphoneType{
    IPHONE11,
    IPHONE13,
    IPHONE15
}