package com.gl.week4.week5.hashing;

public class Employee implements Comparable<Employee>{
    Integer empId;
    String name;
    String fname;
    int age;
    String address;

    public Employee(Integer id, String name, String fname, int age, String address) {
        this.name = name;
        this.fname = fname;
        this.age = age;
        this.address = address;
        this.empId = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "empId=" + empId +
                ", name='" + name + '\'' +
                ", fname='" + fname + '\'' +
                ", age=" + age +
                ", address='" + address + '\'' +
                '}';
    }

    @Override
    public int compareTo(Employee o) {
        return this.age-o.age;
    }
}
