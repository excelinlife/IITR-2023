package com.gl.week4.week5;

import java.util.ArrayList;
import java.util.LinkedList;

public class Day2 {
    public static void main(String[] args) {
        Graph graph = new Graph();
        graph.addNode(new Node('A'));
        graph.addNode(new Node('B'));
        graph.addNode(new Node('C'));
        graph.addNode(new Node('D'));
        graph.addNode(new Node('E'));

        graph.addEdge(0,2);
        graph.addEdge(1,4);
        graph.addEdge(3,2);
        graph.addEdge(2,4);
        graph.addEdge(4,1);
        graph.addEdge(4,2);

        graph.printNode();

    }
}

class Graph{
    ArrayList<LinkedList<Node>> alist;
    public Graph() {
        alist = new ArrayList<>();
    }

    public void addNode(Node node){
        LinkedList<Node> ll = new LinkedList<Node>();
        ll.add(node);
        alist.add(ll);
    }

    public void addEdge(int s, int d){
        LinkedList<Node> list = alist.get(s);
        Node dst = alist.get(d).get(0);
        list.add(dst);
    }

    public boolean checkEdge(int s, int d){
        // LinkedList<Node> ll = alist[s];
        LinkedList<Node> list = alist.get(s);
        Node dst = alist.get(d).get(0);
        for (Node n: list){
            if (n == dst){
                return true;
            }
        }
        return false;
    }

    public void printNode(){
        for (LinkedList<Node> ll:alist){
            for (Node node : ll){
                System.out.print(node.data+"->");
            }
            System.out.println();
        }
    }
}

class Node{
    char data;

    public Node(char data) {
        this.data = data;
    }
}