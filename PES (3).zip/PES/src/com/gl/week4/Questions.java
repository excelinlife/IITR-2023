package com.gl.week4;

import java.util.Arrays;

public class Questions {
    public static void main(String[] args) {

        // I was not giving a sorted array as input
        int[] arr = {1,2,4,5,5,5,5,6,7,8,10};
        Arrays.sort(arr);
        System.out.println(lastOcc(arr, 5));
        int[] height = {0, 2, 0, 2, 1, 0, 1, 3, 2, 1, 2, 1};

        //System.out.println(trapingRain(height));
    }

    public static int binarySearch(int[] arr, int val){
        int st =0;
        int end = arr.length-1;
        while (st <=     end){
            int mid = st + (end-st)/2;
            if (arr[mid] == val){
                return mid;
            }
            else if (val<arr[mid]){
                end =mid-1;
            }
            else {
                st = mid+1;
            }
        }
        return -1;
    }

    public static int[] twoSum(int[] arr, int target){
        Arrays.sort(arr);
        int st = 0;
        int end = arr.length-1;
        while (st<end){
            int sum = arr[st] +arr[end];
            if (target == sum){
                return new int[]{arr[st], arr[end]};
            } else if (target < sum){
                end--;
            } else {
                st++;
            }
        }
        return null;
    }

    public static boolean adjacentSum(int[] arr, int target){
        for (int i = 0; i < arr.length-1; i++) {
            if (arr[i] + arr[i+1] == target){
                return true;
            }
        }
        return false;
    }

    public static int adjacentKSum(int[] arr, int k){
        // 3
        // {4,10,2,7,3,9,8}
        //m  19  w = 20
        int max_sum = 0;
        for (int i = 0; i < k; i++)
            max_sum += arr[i];
        int window_sum = max_sum;
        for (int i = k; i < arr.length; i++) {
            window_sum += arr[i] - arr[i - k];
            max_sum = Math.max(max_sum, window_sum);
        }
        return max_sum;
    }

    /*Input : arr1[] = {1, 2, 3, 4, 5, 6}
    arr2[] = {11, 22, 33, 44}
    Output: {1, 11, 2, 22, 3, 33, 4, 44, 5, 6}

    Input : arr1[] = {1, 2, 3, 4, 5, 6, 7, 8}
    arr2[] = {11, 22, 33, 44}
    Output: {1, 11, 2, 22, 3, 33, 4, 44, 5, 6, 7, 8}*/

    static void alternateMerge(int arr1[], int arr2[],
                               int n1, int n2, int arr3[]){
        int i=0,j=0,k=0;
        while (i<n1 && j<n2){
            arr3[k++] = arr1[i++];
            arr3[k++] = arr2[j++];
        }
        while (i<n1){
            arr3[k++] = arr1[i];
        }
        while (i<n2){
            arr3[k++] = arr2[j];
        }
    }

    public static boolean tripletSum(int[] arr, int target){
        for (int i = 0; i < arr.length-2; i++) {
            for (int j = i+1; j < arr.length-1; j++) {
                for (int k = j+1; k < arr.length; k++) {
                    if (target == arr[i]+arr[j] + arr[k]){
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public static int[] tripletSum2(int[] arr, int target){
        Arrays.sort(arr); // nlogn
        //  {1, 2, 3, 4, 5, 6}
        for (int i = 0; i < arr.length-2; i++) {
            int rest = target - arr[i];
            int st =i+1,end = arr.length-1;
            while (st<end){
                int tSum = arr[st] + arr[end];
                if ( tSum == rest){
                    return new int[]{arr[i],arr[st], arr[end]};
                } else if (tSum<rest){
                    st++;
                } else {
                    end--;
                }
            }
        }
        return null;
    } // {0, 2, 0, 2, 1, 0, 1, 3, 2, 1, 2, 1};
    // st = 1 end = 8, lM = 0 rM=2 res =1;
    public static int trapingRain(int[] height){
        int st=0, end = height.length-1;
        int result = 0, lMax = 0, rMax =0;
        while (st < end){
            if (height[st] < height[end]){
                if (height[st] > lMax) {
                    lMax = height[st];
                } else {
                    result += lMax - height[st];
                } st++;
            } else {
                    if (height[end] > rMax) {
                        rMax = height[end];
                    } else {
                        result += rMax - height[end];
                    } end--;
            }
        }
        return result;
    }

    public static int lastOcc(int[] arr, int val){
        {
            int st =0;
            int end = arr.length-1;
            int res = -1;
            int mid;
            while (st <= end){
                mid = st + (end-st)/2;
                if (arr[mid] == val){
                    st = mid+1;
                    res = mid;
                }
                else if (val<arr[mid]){
                    end =mid-1;
                }
                else {
                    st = mid+1;
                }
            }
            return res;
        }
    }

    public static int firstOcc(int[] arr, int val){
        {
            int st =0;
            int end = arr.length-1;
            int res=-1;
            while (st <= end){
                int mid = st + (end-st)/2;
                if (arr[mid] == val){
                    res = mid;
                    end = mid-1;
                }
                else if (val<arr[mid]){
                    end =mid-1;
                }
                else {
                    st = mid+1;
                }
            }
            return res;
        }
    }

   /* Input: array = {12, 3, 4, 1, 6, 9}, sum = 24;
    Output: 12, 3, 9*/
}
