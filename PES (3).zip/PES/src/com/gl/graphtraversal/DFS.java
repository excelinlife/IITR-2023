package com.gl.graphtraversal;

import java.util.Arrays;
import java.util.List;
import java.util.Stack;

public class DFS {
    Stack<Node> stack;
    public static void main(String[] args) {

        DFS dfs = new DFS();
        Node n1 = new Node(1);
        Node n2 = new Node(2);
        Node n3 = new Node(3);
        Node n4 = new Node(4);
        Node n5 = new Node(7);
        Node n6 = new Node(8);
        Node n7 = new Node(9);
        Node n8 = new Node(11);
        
        n8.setNeighbours(Arrays.asList(n3,n5));
        n3.setNeighbours(Arrays.asList(n1,n8));
        n5.setNeighbours(Arrays.asList(n6,n8));
        n1.setNeighbours(Arrays.asList(n2,n3,n4));
        n2.setNeighbours(Arrays.asList(n1,n7));
        n7.setNeighbours(Arrays.asList(n2,n4,n6));
        n4.setNeighbours(Arrays.asList(n1,n7));
        n6.setNeighbours(Arrays.asList(n3,n5,n7));

        dfs(n8);
        dfs.dfsStack(n8);

    }



    public static void dfsTraverse(List<Node> list){
        for (Node n:list){
            if (!n.getVisited()){
                dfs(n);
            }
        }
    }

    public void dfsStack(Node vertex) {
        if (vertex == null) {
            return;
        }
        this.stack.push(vertex);
        while (!stack.isEmpty()){
            Node n = stack.pop();
            System.out.print(n.getData()+" ");
            n.setVisited(true);
            for (Node  temp : n.getNeighbours()){
                if (!temp.getVisited()){
                    temp.setVisited(true);
                    stack.push(temp);
                }
            }
        }
    }

    public static void dfs(Node vertex) {
        if (vertex == null) {
            return;
        }
        if (!vertex.getVisited()) {
            System.out.println(vertex.getData() + " ");
            vertex.setVisited(true);
            for (Node node : vertex.getNeighbours()) {
                if (!node.getVisited()) {
                    dfs(node);
                }
            }
        }
    }

    public DFS() {
        stack = new Stack<>();
    }
}