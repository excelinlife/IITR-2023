package com.ashish;

class Nod{
    int data;
    Nod next;

    public Nod(int data) {
        this.data = data;
    }
}

public class LinkedList {
    Nod head;

    public LinkedList(Nod head) {
        this.head = head;
    }

    public static void main(String[] args) {
        Nod head = new Nod(1);
        LinkedList linkedList = new LinkedList(head);
        Nod sec = new Nod(2);
        Nod third = new Nod(3);
        Nod fourth = new Nod(4);
        Nod fifth = new Nod(5);

        head.next = sec;
        sec.next = third;
        third.next = fourth;
        fourth.next = fifth;
        // reversePrint(linkedList.head);;
        print(reverseLinkedList(head));
    }

    public static void print(Nod head){
        while (head != null){
            System.out.print(head.data+"->");
            head = head.next;
        }
    }

    public static void reversePrint(Nod head){
        if (head == null){
            return;
        }
        reversePrint(head.next);
        System.out.print(head.data+"->");
    }

    public static Nod reverseLinkedList(Nod head){
        Nod curr= head;
        Nod prev=null;
        Nod next;
        while (curr!=null){
            next = curr.next;
            curr.next = prev;
            prev = curr;
            curr = next;
        }
        Nod h = prev;
        return h;
    }
}
