package com.gl.week8.Day2;

import com.gl.week4.week5.hashing.Employee;

import java.util.*;

public class Q1Demo {
    public static void main(String[] args) {
        Worker e1 = new Worker(123, "john", 2300, "Admin");
        Worker e2 = new Worker(123, "john", 2400, "Development");
        Worker e3 = new Worker(125, "Nagashree", 2600, "frontdesk");
        Worker e4 = new Worker(125, "ANagashree", 2600, "Admin");
        Worker e5 = new Worker(128, "swati", 2200, "Admin");

        Worker e6 = new Worker(123, "john", 2100, "Frontdesk");
        Worker e7 = new Worker(123, "john", 2500, "development");
        Worker e8 = new Worker(125, "Nagashree", 2600, "Admin");

        List<Worker> list = Arrays.asList(e1,e2,e3,e4,e5,e6,e7,e8);
        OptionalDouble development = list.stream().filter(worker -> worker.getDept().equalsIgnoreCase("development")).map(worker -> worker.getSalary()).mapToInt(value -> value).average();
        if (development.isPresent()){
            System.out.println(development.getAsDouble());
        }



    }
}