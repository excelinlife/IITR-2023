package com.gl.week9.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conection {

    public Connection getCon() throws ClassNotFoundException, SQLException {
        String url2 = "jdbc:mysql://localhost:3306/lpg?user=root&password=admin";
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection connection = DriverManager.getConnection(url2);
        return connection;
    }
}
