package com.gl.week4.week5.hashing;

import java.util.Objects;

public class Employee implements Comparable<Employee>{
    Integer empId;
    String name;
    String fname;
    int age;
    String address;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Employee)) return false;
        Employee employee = (Employee) o;
        return age == employee.age && empId.equals(employee.empId) && name.equals(employee.name) && Objects.equals(fname, employee.fname) && address.equals(employee.address);
    }

    @Override
    public int hashCode() {
        return Objects.hash(empId, name, fname, age, address);
    }

    public Employee(Integer id, String name, String fname, int age, String address) {
        if (address.length() == 0){
            throw new BlankAddressException("address is blanck");
        }
        this.name = name;
        this.fname = fname;
        this.age = age;
        this.address = address;
        this.empId = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "empId=" + empId +
                ", name='" + name + '\'' +
                ", fname='" + fname + '\'' +
                ", age=" + age +
                ", address='" + address + '\'' +
                '}';
    }

    @Override
    public int compareTo(Employee o) {
        return this.age-o.age;
    }
}


class BlankAddressException extends RuntimeException{
    public BlankAddressException(String message) {
        super(message);
    }
}