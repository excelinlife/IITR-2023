package com.gl.week4.Day4;

import java.util.Comparator;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;


public class Tree {
    Node root;
    public Tree(Node root) {
        this.root = root;
    }

    public static void preOrder(Node root){
        if (root == null){
            return;
        }
        System.out.print(root.data+" ");
        preOrder(root.left);
        preOrder(root.right);
    }

    public static void postOrder(Node root){
        if (root == null){
            return;
        }
        postOrder(root.left);
        postOrder(root.right);
        System.out.print(root.data+" ");
    }

    public static void inOrder(Node root){
        if (root == null){
            return;
        }
        inOrder(root.left);
        System.out.print(root.data+" ");
        inOrder(root.right);
    }

    public static void BFS(Node root){
        if (root == null){
            return;
        }
        Queue<Node> queue = new LinkedList<>();
        queue.add(root);
        while (!queue.isEmpty()){
            Node temp = queue.remove();
            System.out.print(temp.data+" ");
            if (temp.left != null){
                queue.add(temp.left);
            }
            if (temp.right!= null){
                queue.add(temp.right);
            }
        }
    }

    public static int height(Node root){
        if (root == null){
            return 0;
        }
        else {
            int lHeight = height(root.left);
            int rHeight = height(root.right);
            return Math.max(lHeight, rHeight)+1;
        }
    }

    public static void main(String[] args) {
        PriorityQueue<Integer> pq = new PriorityQueue<>(new Comp()); // min heap
        pq.add(4);
        pq.add(100);
        pq.add(20);
        pq.add(13);
        System.out.println(pq.remove());
        System.out.println(pq.peek());

        Node root = new Node(10);
        Node left = new Node(8);
        Node right = new Node(100);
        root.left = left;
        root.right = right;
        left.left = new Node(20);
        left.right = new Node(80);
        right.left = new Node(40);
        right.right = new Node(50);
        postOrder(root);
        System.out.println("level order");
        BFS(root);
        System.out.println();
        System.out.println(height(root));
    }
}
class Node{
    int data;
    Node left;
    Node right;

    public Node(int data) {
        this.data = data;
    }
}


class Comp implements Comparator<Integer>{

    @Override
    public int compare(Integer o1, Integer o2) {
        return o2-o1;
    }
}