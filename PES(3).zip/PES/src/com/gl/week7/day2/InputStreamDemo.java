package com.gl.week7.day2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class InputStreamDemo {
    public static void main(String[] args) throws FileNotFoundException {
        FileInputStream fi = new FileInputStream("file/myFile.txt");
        try {
            int c;
            while ((c=fi.read())!=-1){
                System.out.print((char) c);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
