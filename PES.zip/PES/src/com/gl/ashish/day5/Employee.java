package com.gl.ashish.day5;

public class Employee {
    int i=20;
    int empNo;
    String name;

    public void show(){
        System.out.println("parent");
    }

    public Employee(){
        System.out.println("employee constructor");
    }

    public Employee(int empNo, String name) {
        System.out.println("parameterized constructor");
        this.empNo = empNo;
        this.name = name;
    }

    public static void main(String[] args) {
        Manager manager = new Manager("ashish");
        manager.show();
    }
}

class  Manager extends Employee{
    String reportees;
    int i=10;
    public Manager(String reportees){
        super(100, "jack");

        System.out.println("manager constructor");
        this.reportees = reportees;
    }

    public void show(){
        super.show();
        System.out.println("child");
    }
}
