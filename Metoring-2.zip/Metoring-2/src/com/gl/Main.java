package com.gl;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Enter the size of array");
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        System.out.println("enter the " + size + " elements");
        int array[] = new int[size];
        for (int i = 0; i < size; i++) {
            array[i] = sc.nextInt();
        }

        MergeSort mergeSort = new MergeSort();
        mergeSort.sort(array, 0, size-1);
        System.out.println("sorted array is : ");
        for (int i = 0; i < size; i++) {
            System.out.println(array[i]);
        }
        int mid = (array.length-1)/2;
        int val = array[mid];
        ArrayRotation ar = new ArrayRotation();
        ar.rotate(array, mid, array.length);
        System.out.println("roated array is : ");
        for (int i = 0; i < size; i++) {
            System.out.println(array[i]);
        }

        SerachInRotated sr = new SerachInRotated();
        System.out.println("search "+ val);
        System.out.println(sr.search(array, val));
    }
}
