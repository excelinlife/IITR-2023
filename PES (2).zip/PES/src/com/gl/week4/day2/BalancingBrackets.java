package com.gl.week4.day2;

import java.util.Scanner;
public class BalancingBrackets {
    static int MaximumlengthBalanced(String str) {
        // ]]]
        // i=11  res =4  st= 2 5
        int n = str.length();
        Stack stk = new Stack(10);
        stk.push(-1);
        int result = 0;
        for (int i = 0; i < n; i++)
        {
            if (str.charAt(i) == '[')
                stk.push(i);
            else
            {
                if(!stk.isEmpty())
                    stk.pop();
                if (!stk.isEmpty())
                    result = Math.max(result, i - stk.peek());
                else
                    stk.push(i);
            }
        }
        return result;
    }
    public static void main (String[] args) {
        Scanner sc= new Scanner(System.in);
        String s= sc.nextLine();
        System.out.println(MaximumlengthBalanced(s));
        sc.close();
    }
}