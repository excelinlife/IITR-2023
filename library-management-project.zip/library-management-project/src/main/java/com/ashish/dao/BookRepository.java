package com.ashish.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ashish.entity.Book;

public interface BookRepository extends JpaRepository<Book, Integer>{
	
}
