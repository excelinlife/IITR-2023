package com.gl.bank;

import com.gl.otp.OTPGenerator;

import java.util.Scanner;

public class Banking {

    private int balance = 1000;
    private int otp;

    Scanner sc = new Scanner(System.in);

    //checkBalance
    public void checkBalance(){
        System.out.println(this.balance);
    }
    // deposit

    public void deposit(int amount){
        if (amount > 0){
            System.out.println("amount "+amount+ " deposited successfully");
            balance+=amount;
        } else {
            System.out.println("amount must be greater than 0");
        }
    }

    // withdraw

    public void withdraw(int amount){
        if (amount>0 && amount < balance){
            System.out.println("amount "+amount+ " withdrawn successfully");
            balance-=amount;
        } else {
            System.out.println("amount must be less then or equal to the balance");
        }
    }

    // transfer

    public void transfer(int amount){
        OTPGenerator otpGenerator = new OTPGenerator();
        int generatedOTP = otpGenerator.generateOTP();
        System.out.println("please use this otp to verify transfer "+generatedOTP);
        System.out.println("please enter the otp..");
        int otp = sc.nextInt();

        if (otp == generatedOTP){
            if (amount>0 && amount <= balance){
                System.out.println("amount "+amount+" transferred successfully");
                balance-=amount;
            } else {
                System.out.println("amount must be less then or equal to the balance");
            }
        } else {
            System.out.println("OTP is invalid...");
        }
    }
}
