package com.gl.ashish;

public class Week3Day4 {
    public static int findMaxSum(int[] nums, int k) {
        int maxSum = 0;
        int windowSum = 0;
        int windowStart = 0;
        for (int windowEnd = 0; windowEnd < nums.length; windowEnd++) {
            windowSum += nums[windowEnd];
            if (windowEnd >= k - 1) {
                maxSum = Math.max(maxSum, windowSum);
                windowSum -= nums[windowStart];
                windowStart++;
            }
        }
        return maxSum;
    }
    public static void main(String[] args) {
        System.out.println(findMaxSum(new int[] {7, 1, 5, 3, 6, 4}, 3));
        System.out.println(findMaxSum(new int[] {2, 1, 5, 1, 3, 2}, 3));
    }
}
