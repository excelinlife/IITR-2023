function majority(nums){
    nums.sort(); // O(nlogn)
    if(nums.length == 0){
        return nums[0];
    }
    let c=0;
    for (let index = 0; index < nums.length-1; index++) {
        if(nums[index] !==nums[index+1]){
            c=0;
        } else{
            c++;
        }
        if(c>=Math.floor(nums.length/2)){
            return nums[index];
        }
    }
}


function majority2(nums){
    let count =0;
    let maj =0;
    for (let index = 0; index < array.length; index++) {
        if(count==0){
            maj=nums[index];
            count++;
        } if(maj==nums[index]){
            count++;
        } else{
            count--;
        }
    }
    return maj;
}

function isAnagram(s1,s2){
    if(s1.length != s2.length){
        return false;
    }
    let first = s1.split("").sort();
    let second = s2.split("").sort();
    for (let index = 0; index < first.length; index++) {
       if( first[index] !== second[index])
        return false;
    }
    return true;
}
console.log(isAnagram("ashish","hhashi"))


function isAnagram2(s1,s2){
    if(s1.length !=s2.length){
        return false;
    }
    let arr = new Array(26).fill(0);
    for (let index = 0; index < s1.length; index++) {
        arr[s1.charAt(index).charCodeAt(0)-97]++
    }

    for (let index = 0; index < s2.length; index++) {
        arr[s2.charAt(index).charCodeAt(0)-97]--
    }

    for (let index = 0; index < arr.length; index++) {
        if(arr[index]!=0){
            return false;
        }
    }
    return true;
}

console.log(isAnagram2("ash123ish","sh321ashi"))

console.log('a'.charCodeAt(0))


function biggest(nums){
    if(nums.length == 1){
        return nums[0];
    }
    let biggest = nums[0];
    for (let index = 0; index < nums.length; index++) {
        if(biggest<nums[index]){
            biggest=nums[index]
        }
    }
    return biggest;
}

function find(s, c){
    for (let index = 0; index < s.length; index++) {
        if(s[index]===c){
            return true
        }
    }
    return false;
}

console.log(find("ashish", 'z'))