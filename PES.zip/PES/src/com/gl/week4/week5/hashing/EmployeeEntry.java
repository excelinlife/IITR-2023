package com.gl.week4.week5.hashing;

public class EmployeeEntry{
    Employee employee;
    int key;
    EmployeeEntry next;

    public EmployeeEntry(Employee employee, int key, EmployeeEntry next) {
        this.employee = employee;
        this.key = key;
        this.next = next;
    }
}