package com.gl.week7.day2;

import jdk.jfr.events.FileReadEvent;

import java.io.*;

public class FileDemo {
    public static void main(String[] args) throws IOException {
        File file = new File("file/myFile.txt");
        FileWriter fw = null;
        try {
            fw = new FileWriter(file, true);
            fw.write("this is a test sentence..");
            fw.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            fw.close();
        }

        FileReader fr = new FileReader(file);
        int c =-1;
        while ((c=fr.read()) != -1){
            System.out.print((char)c);
        }
    }
        /*File file = new File("file/myFile.txt");
        FileWriter fw = new FileWriter(file, true);
        fw.write("this is a test sentence..");
        fw.flush();
        fw.close();
        FileReader fr = new FileReader(file);
        int c =-1;
        while ((c=fr.read()) != -1){
            System.out.print((char)c);
        }
        System.err.println("ashish");
    }*/
}
// read and write the streams
// classes to read character data: Reader(abstract), FileReader BufferedReader
// classes to write character data: Writer(abstrct), FileWriter, BufferedWriter
//stream input and output: System.out System.in System.err
// 