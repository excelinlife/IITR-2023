package com.gl.week6.day4;

import sun.plugin.javascript.navig.Array;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
//Wrapper classes Integer, Float, Double, Byte.....
// and String(will work by default) because they implement comparable interface
public class demo {
    public static void main(String[] args) {
        System.out.println("ashish".compareTo("anish"));
        System.out.println("anish".compareTo("ashish"));
        Student s1 = new Student("132", "john", 29);
        Student s2 = new Student("124", "Jack", 22);

        Student s3 = new Student("129", "jeff", 21);

        Student s4 = new Student("12", "Mark", 25);

        Student s5 = new Student("123", "Sean", 20);

        List<String> list2 = Arrays.asList("johh", "mack", "jeff","bill","steve");
        Collections.sort(list2);
        System.out.println(list2);

        List<Student> list = Arrays.asList(s1,s2,s3,s4,s5);
        System.out.println(list);
        Collections.sort(list);
        System.out.println("after sorting");
        System.out.println(list);
    }

}


class Student implements Comparable<Student>{
    String sId;
    String name;
    Integer age;

    public Student(String sId, String name, Integer age) {
        this.sId = sId;
        this.name = name;
        this.age = age;
    }

    @Override
    public String toString() {
        return "Student{" +
                "sId='" + sId + '\'' +
                ", name='" + name + '\'' +
                ", age=" + age +
                '}';
    }

    @Override
    public int compareTo(Student o) {
        return o.name.compareTo(this.name);
    }
}

