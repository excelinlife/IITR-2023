package com.gl.question;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        String[] arr = {"abc", "bca","acb", "dac","cad","cde","dec","edc"};
        System.out.println(groupAnagram(arr));
    }

    public static List<List<String>> groupAnagram(String[] str){
        Map<String, List<String>> map = new HashMap<>();
        for (String s:str){
            char[] chars = s.toCharArray();
            Arrays.sort(chars);
            String temp = new String(chars);
            if (map.get(temp)!=null){
                List l=map.get(temp);
                l.add(s);
                map.put(temp, l);
            } else {
                List<String> list =new ArrayList<>();
                list.add(s);
                map.put(temp, list);
            }
        }
        return new ArrayList<>(map.values());
    }
}
