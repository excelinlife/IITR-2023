// let names = [];

// // for (let index = 0; index < names.length; index++) {
// //     console.log(names[index])

// // }
// let twoD = [
// [1,2,3],
// [4,5,6],
// ["ashish", "Moitri", "Rahul","Amit",4]
// ]


// //console.log(twoD[2][2])



// let arr = new Array();
// arr.push("apple")
// arr.push("banana")
// //console.log(arr)
// //arr.pop()
// console.log(arr)
// arr.unshift("mango")
// console.log(arr)
// arr.unshift("Orange")
// console.log(arr)
// arr.shift()
// console.log(arr)

// 
// console.log(arr.slice(1,3))

let myArray = ["apple", "banana", "orange", "rahul", "ashish", "Moitri","Amit"];

let newArr = myArray.filter(abc=>abc.startsWith("a"))
console.log(newArr)



// console.log(num.includes(4))


// let sum = num.reduce(function(accumulator, currentValue) {
//     return accumulator + currentValue;
//   })
//   console.log(sum)
// let plusTwo = num.map(a =>a*a)
// console.log(plusTwo)



//console.log(myArray.concat(myArray2))
 //myArray.splice(1, 3, "pear", "watermelon");

//console.log(myArray.join(", "))

// myArray.sort()
// console.log(myArray)
// myArray.reverse()
// console.log(myArray)

let str  = "     ashish Kumar    ";

console.log(str.indexOf("i"))
console.log(str.replace("ashish","Rahul"))
console.log(str)
let hello = `Hello Mr. ${str}`;
//console.log(hello)

//

function removeSpaces(str){
    let ans="";
    for (let index = 0; index < str.length; index++) {
        if(str[index] != " "){
            ans+=str[index];
        }
    }
    return ans;
}
console.log(removeSpaces("Hello, Mr Ashish. How are you doing?"))


let num2 = [1,2,3,4,5]
let sum = num2.reduce((a,b)=>a*b,10)
console.log(sum)


let num = [2,3,[4,5],6,7,[8,[9,50],[8,100]]]

let flatennedArr= num.flat(2)
console.log(flatennedArr)