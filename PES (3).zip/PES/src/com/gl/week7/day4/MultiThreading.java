package com.gl.week7.day4;

public class MultiThreading {
    public static void main(String[] args) throws InterruptedException {
        System.out.println(Thread.currentThread().getName());
        MyThread myThread1 = new MyThread("first");
        //myThread1.setDaemon(true);
        // new thread: born state -> runnable -> running -> dead after run completes
        MyThread myThread2 = new MyThread("second");
       /* MyThread myThread3 = new MyThread();
        MyThread myThread4 = new MyThread();*/
        myThread1.start();
        myThread1.join();
        myThread2.start();
        for (int i = 0; i < 10; i++) {
            System.out.println(i);

        }
        /*myThread3.run();
        myThread4.run();*/

        /*MyRunnable runnable1 = new MyRunnable("first Runnable");
        MyRunnable runnable2 = new MyRunnable("second Runnable");
        Thread t1 = new Thread(runnable1);
        Thread t2 = new Thread(runnable2);
        t1.start();
        t2.start();*/
    }

}

class MyThread extends Thread{
    String name;

    public MyThread(String name) {
        this.name = name;
    }

    @Override
    public void run() {
        for (int i = 0; i < 10; i++) {
            System.out.println("printed by "+name+" " +(i+1));
           // Thread.currentThread().setPriority(10);
           // System.out.println("is daemon "+Thread.currentThread().isDaemon());
            try {
                Thread.sleep(500);
               // System.out.println(Thread.currentThread().getPriority());;
             //   System.out.println(Thread.currentThread().getName());
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println();
    }
}


class MyRunnable implements Runnable{
    String name;

    public MyRunnable(String name) {
        this.name = name;
    }

    @Override
    public void run() {
        for (int i = 0; i < 5; i++) {
            System.out.println("printed by "+name+" "+(i+1));
        }
    }
}