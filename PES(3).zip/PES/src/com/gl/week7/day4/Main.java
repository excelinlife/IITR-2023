package com.gl.week7.day4;

public class Main {
    public static void main(String[] args) {
        Printer p1 = new Printer();
        Printer p2 = new Printer();
        Printer p3 = new Printer();

        ThreadOne t1 = new ThreadOne(p1, "first");
        ThreadOne t2 = new ThreadOne(p2,"second");
        ThreadOne t3 = new ThreadOne(p3,"third");
        t1.start();
        t2.start();
        t3.start();
    }
}
