package com.gl.week6.day4;
import com.gl.week4.week5.hashing.Employee;
import com.gl.week4.week5.hashing.MyComparator;

import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class SortingDemo {
    public static void main(String[] args) {
        Map<Employee, String> map = new TreeMap<>(new MyComparator());
        Set<Employee> set = new TreeSet<>(new MyComparator());
        Employee e1 = new Employee(124,"Manjunath","fname",21," road bangalore");
        Employee e2 = new Employee(125,"Santosh","fname",23,"neeladri  bangalore");
        Employee e3 = new Employee(126,"Nagashree","Illa",26," bangalore");
        Employee e4 = new Employee(127,"Swathi","reddy",23,"e city road bangalore");
        Employee e5 = new Employee(128,"swati","kumari",26,"koramangla road bangalore");
        Employee e6 = new Employee(129,"Jack","Mathew",23,"delhi");
        Employee e7 = new Employee(113,"Preet","Singh",23,"noida");
        map.put(e1, e1.getName());
        map.put(e2, e2.getName());
        map.put(e3, e3.getName());
        map.put(e4, e4.getName());
        map.put(e5, e5.getName());
        map.put(e6, e6.getName());
        map.put(e7, e7.getName());
        System.out.println(map);
    }
}
