package com.gl.week6.day1;

import java.util.*;

public class Collection {
    public static void main(String[] args) {
        int a =8,b=10,c=11;
        int temp = a^b;
        System.out.println(temp^c);

        System.out.println(reverse("ashish"));
        List<Integer> list = new ArrayList<>();
        ArrayList<Integer> al = new ArrayList<>();
        List<Integer> ll = new LinkedList<>();

        System.out.println("Stack Example");

        Stack<Integer> stack = new Stack<>();
        stack.push(1);
        stack.push(2);
        stack.push(3);
        stack.push(4);
        stack.push(5);

        Iterator<Integer> itr = stack.iterator();
        while (itr.hasNext()){
            itr.next();
        }

        System.out.println(stack.peek());
        System.out.println(stack.pop());
        System.out.println(stack.contains(4));

        Queue<Integer> queue = new LinkedList<>();
        queue.add(1);
        queue.add(10);
        queue.add(100);
        queue.add(1000);
        queue.add(1000);

        System.out.println(queue.peek());
        System.out.println(queue.remove());

        System.out.println("List example");

        list.add(100);
        list.add(105);
        list.add(1102);
        list.add(2);
        list.add(6);
        list.add(6);
        list.add(6);
        list.add(6);

        System.out.println(list);

        System.out.println( list.subList(1,4));

        Collections.sort(list,Collections.reverseOrder());

        System.out.println("Set example");

        Set<Integer> set =  new TreeSet<>();
        set.add(1);
        set.add(2);
        set.add(65);
        set.add(60);
        set.add(90);
        set.add(5);
        set.add(10);
        set.add(60);
        System.out.println(set);
  //      list.addAll(set);
       /* System.out.println(list.contains(6));
        list.remove(2);
        System.out.println(list.contains(6));*/

        System.out.println(list.size());
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
        }

        for (int i:list){
            System.out.println((int)i);
        }

       Map<String, Integer> map = new TreeMap<>();
       map.put("Ram",70);
       map.put("Ravana",102);
       map.put("Sita", 70);
       map.put("Indrajeet",70);
       map.put("Lava",6);
        map.put("Lava",8);
        map.put("Lava",80);
        System.out.println(map.get("Lava"));
        System.out.println(map);
        System.out.println(map.keySet());
        System.out.println(map.values());
        Set<String> names = map.keySet();
        for (String s:names){
            System.out.println("ket is "+s+" value is "+map.get(s));
        }

        for ( Map.Entry<String, Integer> entry: map.entrySet() ){
            System.out.println(entry.getKey());
            System.out.println(entry.getValue());
        }

        System.out.println("using iterator");

        Iterator<Integer> iterator = list.listIterator();
        while (iterator.hasNext()){
            System.out.println(iterator.next());
        }
    }

    public static String reverse(String s){
        Stack<Character> st = new Stack<>();
        for (char c:s.toCharArray()){
            st.push(c);
        }
        String res="";
        while (!st.empty()){
            res+=st.pop();
        }
        return res;
    }
}
