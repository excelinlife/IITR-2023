class Queue{
    constructor(){
        this.items = [];
        this.front=0;
        this.rear=-1;
    }
    isEmpty(){
        if(this.front>this.rear){
            return true;
        } else{
            return false;
        }
    }
    enqueue(element){
        this.items.push(element);
        this.rear++;
    }

    dequeue(){
        if(this.isEmpty()){
            return "its empty";
        }
        return this.items.shift();
        this.front++
    }

    front(){
        // keep the check for empty
        return this.items[0];
        // this.items[this.front]
    } 

    rear(){
        // keep the check for empty
        return this.items[this.rear];
        //return this.items[this.items.length-1];
    }

    showQueue(){
        if(this.isEmpty()){
            return "queue is empty";
        } 
        return this.items;
    }
}