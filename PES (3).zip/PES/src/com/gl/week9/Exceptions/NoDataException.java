package com.gl.week9.Exceptions;

public class NoDataException extends RuntimeException{
    public NoDataException(String message) {
        super(message);
    }
}
