package com.gl.ashish;

public class Test {
    public static void main(String[] args) {
        String s1 = "ashish";
        /*String s2 = "ashish";
        System.out.println(s1.substring(4));
        System.out.println(s1);
        String s4 = s1.concat(s2);
        System.out.println(s4);
        System.out.println(s1);
*/
        StringBuffer sb = new StringBuffer("ashish");
        sb.append('c').append('d').append('e').append('f');
        System.out.println(sb);
        String s3 = new String("ashish");
        System.out.println(s1.equals(s3));

    }
}
