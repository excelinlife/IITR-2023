function latgest(first, second, third){
    if(first>second && first>third){
        return first;
    }
    else if(third>second && third>first){
        return third;
    } else
    return second;
}

function fact(n){
    let ans =1;
    for (let index = 1; index <= n; index++){
        ans*=index;
    }
    return ans;
}

console.log(fact(6))

function isPrime(n){
    for (let index = 2 ; index<n/2; index++){
        if(n%index==0){
            return false
        }
     }
     return true;
}

function min(nums){
    let ans = nums[0];
    for (let index = 1; index < nums.length; index++) {
        if(ans>nums[index]){
            ans= nums[index];
        }
    }
    return ans;
}

console.log(isPrime(13))

function sum(nums){
    let res=0;
    for (let index = 0; index < nums.length; index++) {
        res+=nums[index];
    }
    return res;
}

function sum(nums){
    let double;
    for (let index = 0; index < nums.length; index++) {
        double[index]=nums[index]*2;
    }
}