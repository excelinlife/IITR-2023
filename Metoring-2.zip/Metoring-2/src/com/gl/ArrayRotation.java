package com.gl;

public class ArrayRotation {
    public void rotate(int[] arr, int mid, int size){
        for (int i = 0; i < mid; i++) {
            rotateOne(arr,size);
        }
    }

    public void rotateOne(int[] arr, int size){
        int temp=arr[0];
        for (int i = 0; i <size-1; i++) {
            arr[i] = arr[i+1];
        }
        arr[size-1] = temp;
    }

    /*public int[] rotate(int[] arr){
        int mid = (arr.length-1)/2;
        int[] array = new int[arr.length];
        for (int i = 0; i <= mid; i++) {
            array[i] = arr[mid+1+i];
        }
        for (int i = 0; i <= mid; i++) {
            array[mid+1+i] = arr[i];
        }
        return array;
    }*/
}




