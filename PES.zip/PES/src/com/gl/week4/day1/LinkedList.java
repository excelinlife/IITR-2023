package com.gl.week4.day1;

public class LinkedList {
    Node head;

    public LinkedList(Node head) {
        this.head = head;
    }

    public static void main(String[] args) {
        Node first = new Node(1);
        Node second = new Node(2);
        Node third = new Node(3);
        Node fourth = new Node(4);
        LinkedList ll = new LinkedList(first);
        ll.head.next = second;
        second.next = third;
        third.next = fourth;
        System.out.println(llLength(ll.head));

        addAtBeg(ll, 7);
        traverse(ll.head);
        System.out.println();
        addAtEnd(ll, 700);
        traverse(ll.head);
        System.out.println();
        addAtPos(ll, 400, 3);
        traverse(ll.head);
        // head -> 1 ->2 ->3 ->4 ->5
        System.out.println("reversing");
        Node result = reverse(ll.head);
        traverse(result);

       /* Node head = deleteAlternate(ll.head);
        traverse(head);*/
        /*int size = llLength(ll.head);
        System.out.println(sumOfN(ll.head, size, 3));
*/
       /* deleteFromBeg(ll);
        traverse(ll.head);
        System.out.println();
        deleteFromEnd(ll);
        traverse(ll.head);
        System.out.println();
        delFromPos(ll, 5);
        traverse(ll.head);*/
    }

    private static void traverse(Node head){
        while (head != null){
            System.out.print(head.data);
            System.out.print("->");
            head = head.next;
        }
    }

    private static void traverseRec(Node head){
        while (head != null){
            System.out.print(head.data);
            System.out.print("->");
            traverseRec(head.next);
        }
    }

    private static void traverseRev(Node head){
        if (head == null){
            return;
        }
        traverseRev(head.next);
        System.out.print(head.data);
        System.out.print("->");
    }

    private static int llLength(Node head){
        int len = 0;
        while (head != null){
            len++;
            head = head.next;
        }
        return len;
    }

    public static void deleteFromBeg(LinkedList ll){
        ll.head = ll.head.next;
    }

    public static void deleteFromEnd(LinkedList ll){
        Node temp = ll.head;
        while (temp.next.next != null){
            temp = temp.next;
        }
        temp.next = null;
    }

    public static void delFromPos(LinkedList ll, int pos){
        int count = 1;
        Node temp = ll.head;
        while (count<pos-1){
            temp = temp.next;
            count++;
        }
        temp.next = temp.next.next;
    }

    public static void addAtBeg(LinkedList ll, int val){
        Node n = new Node(val);
        n.next = ll.head;
        ll.head = n;
    }

    public static void addAtEnd(LinkedList ll, int val){
        Node temp = ll.head;
        while (temp.next != null){
            temp = temp.next;
        }
        Node n = new Node(val);
        temp.next = n;
    }

    public static void addAtPos(LinkedList ll, int val, int pos){
        int count = 1;
        Node temp = ll.head;
        while (count<pos-1){
            temp = temp.next;
            count++;
        }
        Node n = new Node(val);
        n.next = temp.next;
        temp.next = n;
    }

    public static Node deleteAlternate(Node head){
        Node curr = head;
        while (curr!= null && curr.next!=null){
            curr.next = curr.next.next;
            curr= curr.next;
        }
        return head;
    }

    public static int sumOfN(Node head,int size, int total){
        int temp = size-total;
        int sum = 0;
        while (temp>0){
            head = head.next;
            temp--;
        }
        while (head != null){
            sum+=head.data;
            head=head.next;
        }
        return sum;
    }

    public static Node reverse(Node head){
        Node curr, prev, next;
        curr = head;
        prev = null;
        while (curr != null){
            next = curr.next;
            curr.next = prev;
            prev = curr;
            curr = next;
        }
        head = prev;
        return head;
    }
}

class Node{
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
    }
}
