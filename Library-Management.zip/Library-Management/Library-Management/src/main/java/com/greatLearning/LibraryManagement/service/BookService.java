package com.greatLearning.LibraryManagement.service;

import com.greatLearning.LibraryManagement.entity.Book;
import com.greatLearning.LibraryManagement.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {
    @Autowired
    BookRepository bookRepository;

    public List<Book> findAll() {
        List<Book> books=bookRepository.findAll();
        return books;
    }

    public Book findById(int theId) {
        return bookRepository.findById(theId).get();
    }

    public void save(Book theBook) {
        bookRepository.save(theBook);

    }

    public void deleteById(int theId) {
        bookRepository.deleteById(theId);
    }

    public List<Book> searchBy(String name, String author){
        List<Book> books = bookRepository.findByNameContainsAndAuthorContainsAllIgnoreCase(name, author);
        return books;
    }

}
