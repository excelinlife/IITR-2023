package com.gl.week6.day3;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class InfixPostfix {
    public static void main(String[] args) {
        String s = "a+b*(c^d-e)";
        System.out.println(infixToPostfix(s));
        System.out.println(postfixToInfix("abcd^e-*+"));
    }

    public static int evaluate(String postfix){
        return 0;
    }

    public static String infixToPostfix(String infix){
        String postF = "";
        Stack<Character> st = new Stack<>();
        for (int i = 0; i < infix.length(); i++) {
            char c = infix.charAt(i);
            if (Character.isLetterOrDigit(c)){
                postF+=c;
            } else if (c == '('){
                st.push(c);
            } else if (c==')'){
                while (!st.isEmpty() && st.peek() != '('){
                    postF+=st.pop();
                }
                st.pop();
            }else {
                while (!st.isEmpty() && priority(c)<priority(st.peek()))
                    postF+=st.pop();
                st.push(c);
            }
        }
        while (!st.isEmpty()){
            postF+=st.pop();
        }
        return postF;
    }

    public static String postfixToInfix(String postFix){
        Stack<String> st = new Stack<>();
        int i=0;
        while (i<postFix.length()){
            char c = postFix.charAt(i);
            if (Character.isLetterOrDigit(c)){
                st.push(""+c);
            } else {
                String second = st.pop();
                String first = st.pop();
                String temp = "("+first+""+c+""+second+")";
                st.push(temp);
            }
            i++;
        }
        return st.pop();
    }

    static int priority(char operator){
        switch (operator){
            case  '^':
                return 3;
            case '/':
            case '*':
                return 2;
            case '+':
            case '-':
                return 1;
        }
        return -1;
    }
}
