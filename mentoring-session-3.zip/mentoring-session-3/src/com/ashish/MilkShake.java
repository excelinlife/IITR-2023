package com.ashish;

import java.util.PriorityQueue;
import java.util.Scanner;

public class MilkShake {

    public static void main(String[] args) {
        int[] arr = new int[3];
        Scanner sc = new Scanner(System.in);
        System.out.println("Total number of orders for Mango milkshake");
        arr[0] = sc.nextInt();

        System.out.println("Total number of orders for Orange milkshake");
        arr[1] = sc.nextInt();

        System.out.println("Total number of orders for Pineapple milkshake");
        arr[2] = sc.nextInt();

        System.out.println(timeToPrepare(arr));
    }
    public static int timeToPrepare(int[] orders){
        int time =0;
        PriorityQueue<Integer> maxHeap =  new PriorityQueue<>((a, b) -> b-a);
        for (int i: orders){
            maxHeap.add(i);
        }
        while (maxHeap.size()>1){
            time++;
            int first = maxHeap.remove()-1;
            int second = maxHeap.remove()-1;
            if (first>0){
                maxHeap.add(first);
            }
            if (second>0){
                maxHeap.add(second);
            }
        }
        if (maxHeap.size()==1){
            time+=maxHeap.remove();
        }
        return time;
    }
}
