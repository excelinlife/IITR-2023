class Stack {
    constructor(){
        this.items = []
    }
    push(element){
        this.items.push(element);
    }
    pop(){
        if(this.items.length==0){
            return "empty stack"
        } 
        return this.items.pop();
    }
    peek(){
        return this.items[this.items.length-1];
    }
    isEmpty(){
        return this.items.length===0;
    }
    showStack(){
        if(this.items.length === 0){
            return "its empty";
        }
        let str="";
        for (let index = 0; index < this.items.length; index++) {
            str+=this.items[index]+" "
    }
    return str;
    }
}

let st = new Stack();
st.push(10)
console.log(st.showStack())
st.push(20)
console.log(st.showStack())
console.log(st.isEmpty())
st.push(30)
console.log(st.showStack())
st.pop()
console.log(st.showStack())
console.log(st.peek())
st.pop()
console.log(st.showStack())
console.log(st.pop())


function reverse(str){
    let st = new Stack();
    for (let index = 0; index < str.length; index++) {
        st.push(str[index]);
    }
    let result ="";
    while(!st.isEmpty()){
        result+=st.pop();
    }
    return result;
}

console.log(reverse("ashish"))

class Node{
    constructor(data){
        this.data = data;
        this.next = null;
    }
}

class NodeStack{
    constructor(){
        this.top=null;
    }

    push(val){
        let n = new Node(val);
        Node.next=this.top;
        this.top=n;
    }
    pop(){
        if(this.top == null){
            return "empty"
        } else{
            return this.top().data;
        }
    }
    isEmpty(){
        return this.top == null;
    }
}



class NodeQueue{
    constructor(){
        this.front=null;
        this.rear=null
    }

    push(val){
        let n = new Node(val);
        if(this.front== null && this.rear == null){
            this.front = n;
            this.rear =n;
        }else{
            n.next = this.rear;;
            this.rear=n;
        }
    }
    pop(){
        if(this.front == null && this.rear==null){
            return "empty"
        } else{
            let val = this.front.data;
            this.front=this.front.next;
            return val;
        }
    }
    isEmpty(){
        if(this.front == null && this.rear==null){
            return "empty"
        }
    }

    showQueue(){
        // traverse.
    }
}