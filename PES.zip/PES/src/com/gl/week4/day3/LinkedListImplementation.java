package com.gl.week4.day3;

public class LinkedListImplementation {
    public static void main(String[] args) {
        Stack st = new Stack();
        st.push(3);
        st.push(4);
        st.push(6);
        st.showSt();
        System.out.println();
        st.push(3);
        st.showSt();
        System.out.println();
        st.pop();
        st.showSt();
        System.out.println();
        st.push(9);
        st.showSt();

        System.out.println("testing queue");
        Queue queue = new Queue(10);
        queue.enque(10);
        queue.enque(20);
        queue.enque(30);
        queue.show();
        System.out.println();
        queue.deque();
        queue.show();
        System.out.println();
        queue.enque(40);
        queue.show();
    }
}

class Stack{
    Node top;
    void push(int val){
        Node n =new Node(val);
        n.next = top;
        top = n;
    }

    int pop(){
        if (!isEmpty()){
            Node temp = top;
            top = top.next;
            return temp.data;
        }
        return -1;
    }

    boolean isEmpty(){
        return top == null;
    }

    void showSt(){
        Node temp = top;
        while (temp!=null){
            System.out.print(temp.data+" ");
            temp=temp.next;
        }
    }
}

class NodeQueue{
    Node front;
    Node rear;

    void enque(int data){
        Node n = new Node(data);
        if (front == null && rear == null){
            front = n;
            rear = n;
        } else {
            rear.next = n;
            rear =n;
        }
    }

    void deque(){
        if (isEmpty()){
            System.out.println("empty");
        } else {
            front = front.next;
        }
    }

    boolean isEmpty(){
        if (front == null && rear == null){
            return true;
        } return false;
    }

    void showQ(){
        Node temp = front;
        while (temp!=null){
            System.out.println(temp.data);
            temp=temp.next;
        }
    }


}

class Node{
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
    }
}
