package com.gl.week7.day4;

public class Daemon {
    public static void main(String[] args) {
        DThread dt = new DThread();
        dt.setDaemon(true);
        dt.start();
        System.out.println("end of main");
    }
}


class DThread extends Thread{

    @Override
    public void run() {
        for (int i = 0; i < 10; i++) {
            System.out.println(i);
        }
    }
}
