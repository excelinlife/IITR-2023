package com.ashish;

import java.util.LinkedList;
import java.util.Queue;

class Node{
    int data;
    Node left;
    Node right;

    public Node(int data) {
        this.data = data;
    }
}

public class Tree {
    Node root;

    public Tree(Node root) {
        this.root = root;
    }

    public static void main(String[] args) {
        Tree binaryTree = new Tree(new Node(10));
        Node left = new Node(20);
        Node right = new Node(30);
        binaryTree.root.left = left;
        binaryTree.root.right = right;
        left.left = new Node(40);
        left.right = new Node(50);
        right.left = new Node(60);
        right.right = new Node(70);

        System.out.println(lca(binaryTree.root, 60 , 70).data);
        bfs(binaryTree.root);
        pre(binaryTree.root);
    }

    public static Node lca(Node root, int n1, int n2){
        if (root == null){
            return null;
        }
        if (root.data == n1 || root.data == n2){
            return root;
        }
        System.out.println(root.data);
        Node left = lca(root.left, n1 ,n2);
        Node right = lca(root.right, n1 ,n2);

        if (left!= null && right!=null){
            return root;
        }

        return (left!=null)? left:right;
    }

    public static void bfs(Node root){
        if (root == null){
            System.out.println("tree is empty");
            return;
        }
        Queue<Node> queue = new LinkedList<>();
        queue.add(root);
        while (!queue.isEmpty()){
            Node temp = queue.remove();
            System.out.print(temp.data+"->");
            if (temp.left!=null){
                queue.add(temp.left);
            }
            if (temp.right!=null){
                queue.add(temp.right);
            }
        }
    }

    public static void pre(Node root) {
        if (root == null) {
            return;
        }
        System.out.print(root.data+ "->");
        System.out.println("calling pre with"+root.data);
        pre(root.left);
        System.out.println("calling pre with"+root.right);
        pre(root.right);
    }
}
