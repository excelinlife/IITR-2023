package com.gl.main;

import com.gl.bank.Banking;
import com.gl.customer.Customer;

import java.util.Scanner;

public class Application {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String bankAccountNumber;
        String password;

        Customer customer1 = new Customer("123", "123");

        Banking banking = new Banking();

        System.out.println("welcome to the login page");
        System.out.println();

        System.out.println("Enter the bank Account no ");
        bankAccountNumber = sc.nextLine();
        System.out.println("Enter the password for the corresponding bank account no ");
        password = sc.nextLine();

        if (customer1.getBankAccountNo().equals(bankAccountNumber) && customer1.getPassword().equals(password)){
            int option;
            do {
                System.out.println("-----------------------------------------------");
                System.out.println("Enter the operation number that you want to perform");
                System.out.println("1. Check Balance");
                System.out.println("2. Deposit");
                System.out.println("3. Withdrawl");
                System.out.println("4. Transfer");
                System.out.println("0. Logout");
                System.out.println("-----------------------------------------------");
                option = sc.nextInt();
                switch (option){
                    case 0:
                        option = 0;
                        break;

                    case 1: {
                        banking.checkBalance();
                        break;
                    }

                    case 2: {
                        System.out.println("Enter the amount to deposit");
                        int amount = sc.nextInt();
                        banking.deposit(amount);
                        break;
                    }

                    case 3: {
                        System.out.println("Enter the amount to withdraw");
                        int amount = sc.nextInt();
                        banking.withdraw(amount);
                        break;
                    }

                    case 4: {
                        System.out.println("Enter the amount to transfer");
                        int amount = sc.nextInt();
                        if (amount<=0){
                            System.out.println("please enter valid amount");
                        } else {
                            banking.transfer(amount);
                        }
                        break;
                    }

                    default:
                        System.out.println("please give valid option.....");
                }
            } while (option != 0);
            System.out.println("You have successfully logged out.....");
            sc.close();
        } else {
            System.out.println("Invalid Credentials.....");
        }
        sc.close();
    }
}
