package com.gl.week7.Day3;

import java.io.*;
import java.util.stream.Stream;

public class Serialize {
    public static void main(String[] args) {
        try {
          /*  FileOutputStream fo = new FileOutputStream("serial.txt");
            ObjectOutputStream oo= new ObjectOutputStream(fo);
            Watch w = new Watch(12000, "Fasttrack", "Titan");
            oo.writeObject(w);*/

            FileInputStream fi = new FileInputStream("serial.txt");
            ObjectInputStream oi = new ObjectInputStream(fi);
            Watch temp =  (Watch) oi.readObject();
            System.out.println(temp);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }/* catch (ClassNotFoundException e) {
            e.printStackTrace();
        }*/ catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}

class Watch implements Serializable{
    public static final long id = 1000L;
    int price;
    String model;
    String manufacturer;

    public Watch(int price, String model, String manufacturer) {
        this.price = price;
        this.model = model;
        this.manufacturer = manufacturer;
    }

    @Override
    public String toString() {
        return "Watch{" +
                "price=" + price +
                ", model='" + model + '\'' +
                ", manufacturer='" + manufacturer + '\'' +
                '}';
    }
}