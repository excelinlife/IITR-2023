package com.gl.week7.day1;

import com.gl.week4.week5.hashing.Employee;

public class CustomException {
    public static void main(String[] args) {
        try {
            Employee employee =  new Employee(123,"john","mathew",23,"");
            System.out.println(employee);
        }
        catch (Exception e){
            System.out.println("address is blank"+e.getMessage());
        }
    }
}





// Java built in excetion. User