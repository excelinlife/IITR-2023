package com.gl.graphtraversal;

import java.util.*;

public class BFS {
    public static void main(String[] args) {
        Node n1 = new Node(1);
        Node n2 = new Node(2);
        Node n3 = new Node(3);
        Node n4 = new Node(4);
        Node n5 = new Node(7);
        Node n6 = new Node(8);
        Node n7 = new Node(9);
        Node n8 = new Node(11);

        n8.setNeighbours(Arrays.asList(n3,n5));
        n3.setNeighbours(Arrays.asList(n1,n8));
        n5.setNeighbours(Arrays.asList(n6,n8));
        n1.setNeighbours(Arrays.asList(n2,n3,n4));
        n2.setNeighbours(Arrays.asList(n1,n7));
        n7.setNeighbours(Arrays.asList(n2,n4,n6));
        n4.setNeighbours(Arrays.asList(n1,n7));
        n6.setNeighbours(Arrays.asList(n3,n5,n7));

        bfs(n8);

    }

    public static void bfs(Node vertex){
        if (vertex == null){
            return;
        }
        Queue<Node> queue = new LinkedList<>();
        queue.add(vertex);
        vertex.setVisited(true);
        while (!queue.isEmpty()){
            Node temp = queue.remove();
            System.out.println(temp.getData()+" ");
            for (Node node : temp.getNeighbours()){
                if (!node.getVisited()){
                    queue.add(node);
                    node.setVisited(true);
                }
            }
        }
    }
}

class Node{
    private int data;
    private List<Node> neighbours;
    private Boolean visited;

    public Node(int data) {
        this.data = data;
        this.visited = false;
    }

    public int getData() {
        return data;
    }

    public void setData(int data) {
        this.data = data;
    }

    public List<Node> getNeighbours() {
        return neighbours;
    }

    public void setNeighbours(List<Node> neighbours) {
        this.neighbours = neighbours;
    }

    public Boolean getVisited() {
        return visited;
    }

    public void setVisited(Boolean visited) {
        this.visited = visited;
    }
}
