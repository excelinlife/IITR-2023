package com.gl.week7.day2;

import java.io.*;

public class BufferedDemo {
    public static void main(String[] args) throws IOException {
        FileWriter w = new FileWriter("buffered.txt");
        BufferedWriter bw = new BufferedWriter(w);
        bw.write(55);
        bw.write(75);
        bw.write(65);

        bw.flush();
        FileReader fr = new FileReader("buffered.txt");
        BufferedReader br = new BufferedReader(fr);
        int c;
        while ((c = br.read())!=-1){
            System.out.print((char)c);
        }
    }
}
