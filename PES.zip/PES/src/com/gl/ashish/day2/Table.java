package com.gl.ashish.day2;

import java.util.Scanner;

public class Table {
    public static void main(String[] args) {
       /* System.out.println("which numbers table do you want to print");
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        for (int i = 1; i <=10 ; i++) {
            System.out.println(num*i);
        }*/
        int i=0;
        do {
            System.out.println(i);
            i++;
        } while (i<10);

    }
}
