package com.gl.week4.day1;

public class CircularLL {
    public static void main(String[] args) {
        Node first = new Node(1);
        Node second = new Node(2);
        Node third = new Node(3);
        Node fourth = new Node(4);
        Node fifth = new Node(5);
        LinkedList circlularLL = new LinkedList(first);
        circlularLL.head.next = second;
        second.next = third;
        third.next = fourth;
        fourth.next = fifth;
        fifth.next = first;
        traverse(circlularLL);
    }

    private static void traverse(LinkedList cList){
        Node temp = cList.head;
        while (temp.next != cList.head){
            System.out.print(temp.data);
            System.out.print("->");
            temp = temp.next;
        }
        System.out.println(temp.data);
    }
}
