package com.ashish;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryManagement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(LibraryManagement.class, args);

	}

}
