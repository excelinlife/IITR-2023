package com.gl;

public class TeamFormation {
    public static void main(String[] args) {

    }
}
