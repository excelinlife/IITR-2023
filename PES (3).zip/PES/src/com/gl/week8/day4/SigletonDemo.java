package com.gl.week8.day4;

public class SigletonDemo {
    public static void main(String[] args) {
        //System.out.println(s);
    }
}
