package com.gl.week7.day4;

public class Printer {

     public static synchronized void show(String name) throws InterruptedException {
        for (int i = 0; i < 10; i++) {
            System.out.println("running by "+name);
            Thread.sleep(200);
        }
    }
}
