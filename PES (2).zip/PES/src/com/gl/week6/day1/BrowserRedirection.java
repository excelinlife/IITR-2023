package com.gl.week6.day1;

import java.util.LinkedList;
import java.util.Scanner;

public class BrowserRedirection{
    // Declare and initialize the variables and required objects
    int choice = 0;
    int currentUrl = 0;
    boolean status = true;
    Scanner sc = new Scanner(System.in);
    LinkedList<String> history = new LinkedList<String>();
    public void implementUrlNavigation() {
        System.out.println("Default Browser is Google search engine.");
        history.add("www.google.com");
        do {
            System.out.println("\nEnter your choice\n"
                    + "1. Visit new web page\n"
                    + "2. Go back\n"
                    + "3. Go forward\n"
                    + "4. Exit\n");
            choice=sc.nextInt();
            switch(choice) {
                case 1:
                    newPage();
                    break;
                case 2:
                    goBack();
                    break;
                case 3:
                    goForward();
                    break;
                case 4:
                    status = false;
                    break;
                default:
                    System.out.println("Invalid Input");
            }
// Print the current page you are in and the history everytime
            System.out.println("You are in "+history.get(currentUrl));
            System.out.println("History: "+history);
        }while(status == true);
    }
    public void newPage(){
        System.out.println("Enter the url");
        if(history.size()-1 == currentUrl) {
            history.add(sc.next());
            currentUrl++;
        } // 3. If currentUrl is not pointing to the last page in history then clean the
// history from currentUrl+1 to the end and insert the new page at the end
        else {
// get the sublist and clear it
            history.subList(currentUrl+1, history.size()).clear();
            history.add(sc.next());
            currentUrl++;
        }
    }
    public void goBack() {
// 1. If currentUrl is not pointing to the first page then go back
        if(currentUrl>0) {
            currentUrl--;
        } // 2. If currentUrl is pointing to the first page say that we cannot go back
        else {
            System.out.println("This is the first page");
        }
    }
    public void goForward() {
// 1. If currentUrl is not pointing to the last page then go forward
        if(currentUrl<history.size()-1) {
            currentUrl++;
        } // 2. If currentUrl is pointing to the last page say that we cannot go forward
        else {
            System.out.println("This is the last page");
        }
    }
    public static void main(String[] args) {
// 1. create an object
        BrowserRedirection browserRedirection = new BrowserRedirection();
// 2. call the required method
        browserRedirection.implementUrlNavigation();
    }
}
